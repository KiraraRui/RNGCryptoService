﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RNGCryptoServiceProvider1
{
    class Encrypter
    {
        public static string Encrypt(string message)
        {

            //this is the alphabet we use
        char[] alphabet = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            
            char[] secretMessage = message.ToCharArray(); // here we got the message that puts the characters into the array

            char[] encryptedMessage = new char[secretMessage.Length];

            int i;
            for (i = 0; i < secretMessage.Length; i++)
            {
                char secretItem = secretMessage[i]; 
                int index = Array.IndexOf(alphabet, secretItem); 
                int letterPosition = (index += 1) % 26; // Modulus Operator and remainder of after an integer division
                char encryptedCharacter = alphabet[letterPosition];  
                // Here above, we’re assigning the value of alphabet[letterPosition] which is to the variable encryptedCharacter where it gets the encrypted character as a CHAR
                encryptedMessage[i] = encryptedCharacter; // here we use that same char to the encrypted message!
            }

            string superSecretMessage = String.Join("", encryptedMessage); // Concatenates our element values collection and then uses it for our message
            return superSecretMessage; // lets return the bitch
        }

        public static string Dencrypt(string demessage)
        {
            
            char[] alphabet = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

            char[] secretMessage = demessage.ToCharArray();

            char[] encryptedMessage = new char[secretMessage.Length];

            int i;
            for (i = 0; i < secretMessage.Length; i++)
            {
                char secretItem = secretMessage[i];
                int index = Array.IndexOf(alphabet, secretItem);
                int letterPosition = (index += -1) % 26; // legit just did a copy paste and added a - minus to the 1 cus that is def smart O_O?
                char encryptedCharacter = alphabet[letterPosition];
                encryptedMessage[i] = encryptedCharacter;
            }

            string superSecretMessage = String.Join("", encryptedMessage);
            return superSecretMessage;
        }



    }
    }

